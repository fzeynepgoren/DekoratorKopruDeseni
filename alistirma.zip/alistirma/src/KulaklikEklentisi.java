public class KulaklikEklentisi extends TelefonEklentiler
{
    KulaklikEklentisi(ITelefon telefon) {
        super(telefon);
    }
    public String telefonDetay()
    {
        return ekleniliTelefon.telefonDetay()+" kulaklık eklendi";
    }
}
