public class MAin {
    public static void main (String []args)
    {
        ITelefon telefon =new Telefon();
        ITelefon telefon2 =new Telefon();


        System.out.println(telefon.telefonDetay());

        telefon= new KulaklikEklentisi(telefon);
        System.out.println(telefon.telefonDetay());

        telefon= new KılıfEklentisi(telefon);
        System.out.println(telefon.telefonDetay());

        telefon2= new KılıfEklentisi(telefon2);
        System.out.println(telefon2.telefonDetay());
    }
}
