public interface ITelefon
{
    public String telefonDetay();

}
