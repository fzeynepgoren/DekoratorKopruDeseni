public class TelefonEklentiler implements  ITelefon
{
ITelefon ekleniliTelefon;
TelefonEklentiler(ITelefon telefon)
{
    this.ekleniliTelefon= telefon;

}

    @Override
    public String telefonDetay() {
        return ekleniliTelefon.telefonDetay();
    }
}
