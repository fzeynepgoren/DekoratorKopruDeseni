public class KılıfEklentisi extends TelefonEklentiler
{
    KılıfEklentisi(ITelefon telefon)
    {
        super(telefon);
    }
    public String telefonDetay()
    {
        return ekleniliTelefon.telefonDetay()+" Kilif eklendi";
    }


}




