public class Telefon  implements ITelefon
{
    @Override
    public String telefonDetay() {
        return "Telefon";
    }
}
